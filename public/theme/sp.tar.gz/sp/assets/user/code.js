define(['domReady'],function (domReady){

	//card
	$("#card-update").click(function () {
		$.ajax({
			type: "POST",
			url: "code",
			dataType: "json",
			data: {
				code: $("#code").val()
			},
			success: function (data) {
				if (data.ret) {
					layer.msg(data.msg);
					window.setTimeout("location.href=window.location.href",1800);
				} else {
					layer.msg(data.msg);
					window.setTimeout("location.href=window.location.href",1800);
				}
			},
			error: function (jqXHR) {
				layer.msg("发生错误：" + jqXHR.status);
			}
		})
	});

	//f2f
	var pid = 0;
    f2fpay=function(){

    	layer.open({
		  type: 1,
		  title:false,
		  closeBtn:0,
		  area: '400px',
		  shadeClose: false,
		  content: $('#loading-modal')
		});

		$.ajax({
				type: "POST",
                url: "/user/payment/purchase",
                dataType: "json",
                data: {
                    amount: $("#amount").val()
                },
			success: function (data) {
				if (data.ret) {

					layer.closeAll();
					$(".layui-layer-shade").fadeOut();

                    console.log(data);
                    pid = data.pid;
                    $("#qrarea").html('<div class="text-center"><p>请使用手机支付宝扫描二维码支付</p><a id="qrcode" style="padding-top:10px;display:inline-block"></a><p>手机可点击二维码唤起支付宝支付</p></div>');                        
                    new QRCode("qrcode", {
                        render: "canvas",
                        width: 200,
                        height: 200,
                        text: encodeURI(data.qrcode)
                    });
                    $('#qrcode').attr('href',data.qrcode);
                    setTimeout(fdmf, 1000);
                } else {
                    layer.msg(data.msg,{
						time: 1800
					}
					,function(){
					  $(".layui-layer-shade").fadeOut();
					  layer.closeAll();
					});
                }
			}
		});
    }

    fdmf=function(){
        $.ajax({
            type: "POST",
            url: "/payment/status",
            dataType: "json",
            data: {
                pid:pid
            },
            success: function (data) {
                if (data.result) {
                	console.log(data);
                	//clearTimeout(dfmtid);
                    $("#qrarea").hide();                    
                    layer.msg("充值成功！")
                    window.setTimeout("location.href=window.location.href",1800);
                }
            },
            error: function (jqXHR) {
                console.log(jqXHR);
            }
        });
        dfmtid = setTimeout(fdmf, 1000); //循环调用触发setTimeout       
    }


    //daimipay
	var type = "alipay";
	var pid = 0;

	$(".dmpay-type").click(function(){
		type = $(this).data("pay");		
	});

	domReady(function(){

	 $("#daimisubmit").click(function(){
	 	$(this).html('已经提交，请等待……').prop("disabled",true);
		var price = parseFloat($("#amount").val());
		console.log("将要使用"+type+"方法充值"+price+"元")
		if(isNaN(price)){
			layer.msg("请填写金额")
		}
		$.ajax({
			'url':"/user/payment/purchase",
			'data':{
				'price':price,
				'type':type,
			},
			'dataType':'json',
			'type':"POST",
			success:function(data){
				console.log(data);
				if(data.errcode==-1){
					layer.msg(data.errmsg);
					window.setTimeout("location.href=window.location.href",1800);
				}
				//
				if(data.errcode==0){
					pid = data.pid;
					if(type=="wepay"){
						layer.open({
							  type: 1, 
							  content:'<div class="text-center">使用微信扫描二维码支付.<div id="dmy" style="padding-top:10px;"></div></div>'
						});
						$("#dmy").qrcode({
							"text": data.code
						});
                        setTimeout(fdaimi, 2000);
					}else if(type=="alipay"){
						layer.open({
							  type: 1, 
							  content:'正在跳转到支付宝...'+data.code
						});
					}else if(type=="qqpay"){
						layer.open({
							  type: 1, 
							  content:'<div class="text-center">使用QQ扫描二维码支付.<div id="dmy"></div></div>'
						});
						$("#dmy").qrcode({
							"text": data.code
						});
                        setTimeout(fdaimi, 2000);
					}
				}

				//
			}
		});

		fdaimi=function(){
			$.ajax({
				type: "POST",
				url: "/doiam/status",
				dataType: "json",
				data: {
					pid:pid
				},
				success: function (data) {
					if (data.status) {
						//clearTimeout(ftid);
						layer.msg("充值成功！")
						window.setTimeout("location.href=window.location.href",1800);
					}
				}
			});
			ftid = setTimeout(fdaimi, 1000);
		}
		setTimeout(fdaimi, 2000);
	});

 });


	//trimepay
	var pid = 0;

    trimepay=function(type){
        if (type==='Alipay'){
            if(/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)) {
                type = 'ALIPAY_WAP';
            } else {
                type = 'ALIPAY_WEB';
            }
        }

        var price = parseFloat($("#amount").val());

        console.log("将要使用 "+ type + " 充值" + price + "元");
        if (isNaN(price)) {
            layer.msg("非法的金额!")
            return;
        }

        layer.open({
		  type: 1,
		  title:false,
		  closeBtn:0,
		  area: '400px',
		  shadeClose: false,
		  content: $('#loading-modal')
		});

        $.ajax({
            'url': "/user/payment/purchase",
            'data': {
                'price': price,
                'type': type,
            },
            'dataType': 'json',
            'type': "POST",
            success: function (data) {
                if (data.code == 0) {
                    console.log(data);
                    layer.closeAll();
					$(".layui-layer-shade").fadeOut();
                    if(type === 'ALIPAY_WAP' || type ==='ALIPAY_WEB'){
                        window.location.href = data.data;
                        trimetid = setTimeout(trimef, 1000); //循环调用触发setTimeout
                    } else {
                        pid = data.pid;
                        $("#qrarea").html('<div class="text-center"><p>使用微信扫描二维码支付</p><p>充值完毕后会自动跳转</p><div align="center" id="qrcode" style="padding-top:10px;"></div></div>');
                        var qrcode = new QRCode("qrcode", {
                            render: "canvas",
                            width: 200,
                            height: 200,
                            text: encodeURI(data.data)
                        });
                        trimetid = setTimeout(trimef, 1000); //循环调用触发setTimeout
                    }
                } else {
                    layer.msg(data.msg,{
							time: 1800
						}
						,function(){
						  $(".layui-layer-shade").fadeOut();
						  layer.closeAll();
						});
                    console.log(data);
                }
            }
        });
        
    }

    trimef=function(){
        $.ajax({
            type: "POST",
            url: "/payment/status",
            dataType: "json",
            data: {
                pid:pid
            },
            success: function (data) {
                if (data.result) {
                    console.log(data);
                    //clearTimeout(trimetid);
                    $("#qrarea").hide();
                    layer.msg("充值成功！")
                    window.setTimeout("location.href=window.location.href",1800);
                }
            },
            error: function (jqXHR) {
                console.log(jqXHR);
            }
        }); 
        trimetid = setTimeout(trimef, 1000); //循环调用触发setTimeout    
    }
    

	//tomatopay
	var type = "wxpay";
	var type = "alipay";
	var pid = 0;
	$(".fqpay-type").click(function(){
		type = $(this).data("pay");
	});

	domReady(function(){

		$("#fqpay-update").click(function(){
			var price = parseFloat($("#amount").val());
			console.log("将要使用"+type+"方法充值"+price+"元")
			if(isNaN(price)){
				layer.msg("非法的金额!")
			}
			$.ajax({
				url:"/user/payment/purchase",
				data:{
					price:price,
					type:type,
				},
				dataType:"json",
				type:"POST",
				success:function(data){
					console.log(data);
					if(data.errcode==-1){
						layer.msg(data.errmsg)
					}
					if(data.errcode==0){
						pid = data.pid;
						if(type=="wxpay"){
							layer.open({
							  type: 1, 
							  content:'正在跳转到微信...'+data.code
							});
						}else if(type=="alipay"){
							layer.open({
							  type: 1, 
							  content:'正在跳转到支付宝...'+data.code
							});
						}
					}
				}
			});
			setTimeout(f, 1000);
		});

	});

	//tomato & bitpay
	var type = "alipay";
	var pid = 0;
	$(".tbpay-type").click(function(){
		type = $(this).data("pay");
	});

	domReady(function(){		

		$("#tbpay-update").click(function(){
			var price = parseFloat($("#tbamount").val());
			console.log("将要使用"+type+"方法充值"+price+"元")
			if(isNaN(price)){
				layer.msg("非法的金额!")
			}


			$.ajax({
				url:"/user/payment/purchase",
				data:{
					price:price,
					type:type,
				},
				dataType:"json",
				type:"POST",
				success:function(data){
					console.log(data);
					if(data.errcode==-1){
						layer.msg(data.errmsg)
					}
					if(data.errcode==0){
						pid = data.pid;
						if(type=="wxpay"){
							layer.open({
							  type: 1, 
							  content:'正在跳转到微信...'+data.code
							});
						}else if(type=="alipay"){
							layer.open({
							  type: 1, 
							  content:'正在跳转到支付宝...'+data.code
							});
						}else if (type == "bitpay") {
							layer.open({
							  type: 1, 
							  content:'正在跳转到Bitpay数字货币支付...'+data.code
							});
							window.location.href = data.url;
						}
					}
				}
			});
			setTimeout(f, 1000);
		});

	});

  
	// BitpayX
	var bitpayXType = "alipay";
	var selectedType = "ALIPAY";
	var pid = 0;
	$(".tbpayx-type").click(function(){
		bitpayXType = $(this).data("pay");
		if (bitpayXType === 'alipay') selectedType = 'ALIPAY';
		if (bitpayXType === 'wxpay') selectedType = 'WECHAT';
		if (bitpayXType === 'bitpay') selectedType = 'BITPAY';
	});

	domReady(function(){		

		$("#tbpayx-update").click(function(){
			var price = parseFloat($("#tbxamount").val());
			console.log("将要使用"+bitpayXType+" "+selectedType+"方法充值"+price+"元")
			if(isNaN(price)){
				layer.msg("非法的金额!")
			}

		
          
			$.ajax({
				url:"/user/payment/purchase",
				data:{
					price:price,
					type:selectedType,
                    
				},
				dataType:"json",
				type:"POST",
				success:function(data){
					console.log(data);
					if(data.errcode==-1){
						layer.msg(data.errmsg)
					}
					if(data.errcode==0){
						pid = data.pid;
						if(bitpayXType=="wxpay"){
							layer.open({
							  type: 1, 
							  content:'正在跳转到微信...'
							});
							window.location.href = data.url;
						}else if(bitpayXType=="alipay"){
							layer.open({
							  type: 1, 
							  content:'正在跳转到支付宝...'
							});
							window.location.href = data.url;
						}else if (bitpayXType == "bitpay") {
							layer.open({
							  type: 1, 
							  content:'正在跳转到Bitpay数字货币支付...'
							});
							window.location.href = data.url;
						}
					}
				}
			});
			setTimeout(f, 1000);
		});

	});
  
  
	function f(){
        $.ajax({
            type: "POST",
            url: "/payment/status",
            dataType: "json",
            data: {
                pid: pid
            },
            success: function (data) {
                if (data.result) {
                    console.log(data);
                    layer.msg("充值成功！");
                    window.setTimeout("location.href=window.location.href",1000);
                }
            },
            error: function (jqXHR) {
                console.log(jqXHR);
            }
        });
        tid = setTimeout(f, 1000); //循环调用触发setTimeout
    }

	//

	//



})